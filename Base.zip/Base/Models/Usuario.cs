﻿namespace AuthService.Models
{
    public class Usuario
    {
        // La llave primaria que pide la base de datos
        public int IdUsuario { get; set; }
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public bool Activo { get; set; }
    }

    // Esta clase servirá para recibir los datos del Login (Header/Body)
    public class LoginRequest
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class RefreshRequest
    {
        public string RefreshToken { get; set; } = string.Empty;
    }
}
